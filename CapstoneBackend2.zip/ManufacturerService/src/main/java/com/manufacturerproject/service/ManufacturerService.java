package com.manufacturerproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.manufacturerproject.entity.Manufacturer;



public interface ManufacturerService {

	List<Manufacturer> getAllManufacturers();
    Manufacturer getManufacturerById(Long id);
    Manufacturer createManufacturer(Manufacturer manufacturer);
    Manufacturer updateManufacturer(Long id, Manufacturer manufacturer);
    void deleteManufacturer(Long id);
}

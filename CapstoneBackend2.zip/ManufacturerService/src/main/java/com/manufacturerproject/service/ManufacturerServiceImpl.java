package com.manufacturerproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manufacturerproject.entity.Manufacturer;
import com.manufacturerproject.exception.ResourceNotFoundException;
import com.manufacturerproject.repoitory.ManufacturerRepository;

@Service
public class ManufacturerServiceImpl implements ManufacturerService {

	@Autowired
	private ManufacturerRepository manufacturerRepository;

	@Override
	public List<Manufacturer> getAllManufacturers() {
		// TODO Auto-generated method stub
		return manufacturerRepository.findAll();
	}

	@Override
	public Manufacturer getManufacturerById(Long id) {
		// TODO Auto-generated method stub
		return manufacturerRepository.findById(id).
				orElseThrow(()->new ResourceNotFoundException("Manufacturer not found with id " + id));
	}

	@Override
	public Manufacturer createManufacturer(Manufacturer manufacturer) {
		// TODO Auto-generated method stub
		return manufacturerRepository.save(manufacturer);
	}

	@Override
	public Manufacturer updateManufacturer(Long id, Manufacturer manufacturer) {
		// TODO Auto-generated method stub
		Manufacturer manufacturerDetails = manufacturerRepository.findById(id).
				orElseThrow(() -> new RuntimeException("Manufacturer not found with id " + id));

        manufacturerDetails.setName(manufacturer.getName());
        manufacturerDetails.setCountry(manufacturer.getCountry());

        return manufacturerRepository.save(manufacturerDetails);
	}

	@Override
	public void deleteManufacturer(Long id) {
		// TODO Auto-generated method stub
		Manufacturer manufacturer = manufacturerRepository.findById(id).
				orElseThrow(() -> new RuntimeException("Manufacturer not found with id " + id));
        manufacturerRepository.delete(manufacturer);
	}
}

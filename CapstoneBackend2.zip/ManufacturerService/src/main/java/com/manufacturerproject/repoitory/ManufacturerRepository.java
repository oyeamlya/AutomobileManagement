package com.manufacturerproject.repoitory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.manufacturerproject.entity.Manufacturer;

public interface ManufacturerRepository extends JpaRepository<Manufacturer, Long> {

}

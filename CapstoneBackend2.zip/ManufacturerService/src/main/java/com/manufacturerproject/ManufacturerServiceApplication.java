package com.manufacturerproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManufacturerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManufacturerServiceApplication.class, args);
		System.out.println("Project successfully");
	}

}

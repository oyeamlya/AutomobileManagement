package com.manufacturerproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManufacturerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.customerproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customerproject.entity.Customer;
import com.customerproject.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<Customer> getAllCustomers() {
    	// TODO Auto-generated method stub
        return customerRepository.findAll();
    }

	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}
	
    @Override
    public Customer getCustomerById(Long id) {
    	// TODO Auto-generated method stub
        return customerRepository.findById(id).orElseThrow(() -> new RuntimeException("Customer not found with id " + id));
    }
    
	@Override
	public Customer updateCustomer(Long id, Customer customer) {
		// TODO Auto-generated method stub
		Customer customerDetails = customerRepository.findById(id).orElseThrow(() -> new RuntimeException("Customer not found with id " + id));

		customerDetails.setName(customer.getName());
		customerDetails.setEmail(customer.getEmail());
		customerDetails.setPhone(customer.getPhone());

        return customerRepository.save(customerDetails);
	}
	
	 @Override
	 public void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
       Customer customer = customerRepository.findById(id).orElseThrow(() -> new RuntimeException("Customer not found with id " + id));
	   customerRepository.delete(customer);
	 }

}


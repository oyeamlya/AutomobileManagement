package com.automobileproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.automobileproject.entity.Automobile;
import com.automobileproject.repository.AutomobileRepository;
import com.automobileproject.service.AutomobileService;

@RestController
@RequestMapping("/automobile")
public class AutomobileController {
    
    @Autowired
    private AutomobileService automobileService;
    
    @Autowired
    private AutomobileRepository automobileRepository;
    
    // Get all automobiles
    @GetMapping("/all")
    public List<Automobile> getAllAutomobiles() {
        return automobileService.getAllAutomobiles();
    }
    
    // Get automobile by id
    @GetMapping("/{id}")
    public Automobile getAutomobileById(@PathVariable Long id) {
        return automobileService.getAutomobileById(id);
    }
    
    // Create a new automobile
    @PostMapping("/save")
    public Automobile createAutomobile(@RequestBody Automobile automobile) {
        return automobileService.createAutomobile(automobile);
    }
    
    // Delete an automobile by id
    @DeleteMapping("/{id}")
    public void deleteAutomobile(@PathVariable Long id) {
        automobileService.deleteAutomobile(id);
    }
    
    // Update an automobile by id
    @PutMapping("/{id}")
    public Automobile updateAutomobile(@PathVariable Long id, @RequestBody Automobile automobile) {
        return automobileService.updateAutomobile(id, automobile);
    }
    
    // Get automobiles by year
    @GetMapping("/year/{year}")
    public List<Automobile> getAutomobilesByYear(@PathVariable int year) {
        return automobileService.getAutomobilesByYear(year);
    }
    
    // Get automobiles by manufacturer id
    @GetMapping("/manufacturer/{manufacturerId}")
    public List<Automobile> getAutomobilesByManufacturer(@PathVariable Long manufacturerId) {
        return automobileService.getAutomobilesByManufacturer(manufacturerId);
    }
    
    // Get automobile with its manufacturer details by automobile id
    @GetMapping("/{id}/manufacturer")
    public Automobile getAutomobileWithManufacturer(@PathVariable Long id) {
        return automobileService.getAutomobileWithManufacturer(id);
    }
}

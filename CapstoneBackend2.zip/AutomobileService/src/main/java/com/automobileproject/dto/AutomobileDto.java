package com.automobileproject.dto;

public class AutomobileDto {

	 private String make;
	    private String model;
	    private int year;
	    private double price;
	    private Long manufacturerId;
		public AutomobileDto() {
			super();
			// TODO Auto-generated constructor stub
		}
		public AutomobileDto(String make, String model, int year, double price, Long manufacturerId) {
			super();
			this.make = make;
			this.model = model;
			this.year = year;
			this.price = price;
			this.manufacturerId = manufacturerId;
		}
		public String getMake() {
			return make;
		}
		public void setMake(String make) {
			this.make = make;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public Long getManufacturerId() {
			return manufacturerId;
		}
		public void setManufacturerId(Long manufacturerId) {
			this.manufacturerId = manufacturerId;
		}
		@Override
		public String toString() {
			return "AutomobileDto [make=" + make + ", model=" + model + ", year=" + year + ", price=" + price
					+ ", manufacturerId=" + manufacturerId + "]";
		}
	    
	    
}

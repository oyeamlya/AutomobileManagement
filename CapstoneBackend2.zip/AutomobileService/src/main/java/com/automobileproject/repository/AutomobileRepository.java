package com.automobileproject.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.automobileproject.entity.Automobile;

public interface AutomobileRepository extends JpaRepository<Automobile, Long>{

	List<Automobile> findByYear(int year);

	List<Automobile> findByManufacturerId(Long manufacturerId);

}

package com.automobileproject.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.automobileproject.entity.Automobile;
import com.automobileproject.entity.Manufacturer;
import com.automobileproject.exception.ResourceNotFoundException;
import com.automobileproject.repository.AutomobileRepository;

@Service
public class AutomobileServiceImpl implements AutomobileService{

	@Autowired
	private AutomobileRepository automobileRepository;
	
	@Autowired
    private RestTemplate restTemplate;

	@Override
	public List<Automobile> getAllAutomobiles() {
		// TODO Auto-generated method stub
		return automobileRepository.findAll();
	}

	@Override
	public Automobile getAutomobileById(Long id) {
		// TODO Auto-generated method stub
		return automobileRepository.findById(id).
				orElseThrow(() -> new ResourceNotFoundException("Automobile Not Found"));
	}

	@Override
    public Automobile createAutomobile(Automobile automobile) {
        // Fetch manufacturer by ID directly using RestTemplate
        return automobileRepository.save(automobile);
    }


	@Override
	public Automobile updateAutomobile(Long id, Automobile automobile) {
		// TODO Auto-generated method stub
		Automobile automobileDetails = automobileRepository.findById(id).
				orElseThrow(()->new ResourceNotFoundException("Automobile not found with id "+id));
		
		automobileDetails.setMake(automobile.getMake());
		automobileDetails.setModel(automobile.getModel());
		automobileDetails.setPrice(automobile.getPrice());
		automobileDetails.setYear(automobile.getYear());
		
		return automobileRepository.save(automobileDetails);
	}

	@Override
	public void deleteAutomobile(Long id) {
		// TODO Auto-generated method stub
		Automobile automobile = automobileRepository.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("Automobile not found with id "+id));
		automobileRepository.delete(automobile);
	}

	@Override
	public List<Automobile> getAutomobilesByYear(int year) {
		// TODO Auto-generated method stub
		return automobileRepository.findByYear(year);
	}
	
	@Override
	public List<Automobile> getAutomobilesByManufacturer(Long manufacturerId) {
		// TODO Auto-generated method stub
	    return automobileRepository.findByManufacturerId(manufacturerId);
	}
	
    public Automobile getAutomobileWithManufacturer(Long id) {
        Automobile automobile = automobileRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Automobile not found with id " + id));

        Manufacturer manufacturer = restTemplate.getForObject(
            "http://localhost:8082/manufacturers/" + automobile.getManufacturer().getId(), 
            Manufacturer.class
        );
        if (manufacturer == null) {
            throw new ResourceNotFoundException("Manufacturer not found for id " + automobile.getManufacturer().getId());
        }
        automobile.setManufacturer(manufacturer);
        return automobile;
    }
}


package com.automobileproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.automobileproject.entity.Automobile;

@Service
public interface AutomobileService {
    List<Automobile> getAllAutomobiles();
    Automobile getAutomobileById(Long id);
    Automobile createAutomobile(Automobile automobile);
    Automobile updateAutomobile(Long id, Automobile automobile);
    void deleteAutomobile(Long id);
	List<Automobile> getAutomobilesByYear(int year);
	List<Automobile> getAutomobilesByManufacturer(Long manufacturerId);
	Automobile getAutomobileWithManufacturer(Long id);
}


package com.maintenanceproject.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Maintenance {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private Date date;
	private String description;
	
	@ManyToOne
	@JoinColumn(name="automobile_id")
	private Automobile automobile;

	public Maintenance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Maintenance(Long id, Date date, String description, Automobile automobile) {
		super();
		this.id = id;
		this.date = date;
		this.description = description;
		this.automobile = automobile;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Automobile getAutomobile() {
		return automobile;
	}

	public void setAutomobile(Automobile automobile) {
		this.automobile = automobile;
	}

	@Override
	public String toString() {
		return "Maintenance [id=" + id + ", date=" + date + ", description=" + description + ", automobile="
				+ automobile + "]";
	}
	
	
}

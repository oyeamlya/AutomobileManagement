package com.maintenanceproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.maintenanceproject.entity.Automobile;
import com.maintenanceproject.entity.Maintenance;
import com.maintenanceproject.exception.ResourceNotFoundException;
import com.maintenanceproject.repository.MaintenanceRepository;

@Service
public class MaintenanceServiceImpl implements MaintenanceService{

	@Autowired
    private MaintenanceRepository maintenanceRepository;
	
	@Autowired
    private RestTemplate restTemplate;
	
	@Override
	public List<Maintenance> getAllMaintenanceRecords() {
		// TODO Auto-generated method stub
		return maintenanceRepository.findAll();
	}

	@Override
	public Maintenance getMaintenanceById(Long id) {
		// TODO Auto-generated method stub
		return maintenanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Maintenance record not found with id " + id));
	}

	@Override
	public List<Maintenance> getMaintenanceByAutomobileId(Long automobileId) {
		// TODO Auto-generated method stub
		return maintenanceRepository.findByAutomobileId(automobileId);
	}

	@Override
	public Maintenance createMaintenance(Maintenance maintenance) {
		// TODO Auto-generated method stub
		return maintenanceRepository.save(maintenance);
	}

	@Override
	public Maintenance updateMaintenance(Long id, Maintenance maintenance) {
		// TODO Auto-generated method stub
		Maintenance existingMaintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Maintenance record not found with id " + id));

        existingMaintenance.setDate(maintenance.getDate());
        existingMaintenance.setDescription(maintenance.getDescription());
        return maintenanceRepository.save(existingMaintenance);
	}

	@Override
	public void deleteMaintenance(Long id) {
		// TODO Auto-generated method stub
		Maintenance maintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Maintenance record not found with id " + id));
        maintenanceRepository.delete(maintenance);
	}

	@Override
	public Maintenance getMaintenanceWithAutomobile(Long id) {
		// TODO Auto-generated method stub
        Maintenance maintenance = maintenanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Maintenance record not found with id " + id));
 
        Automobile automobile = restTemplate.getForObject(
            "http://localhost:8081/automobile/" + maintenance.getAutomobile().getId(), 
            Automobile.class
        );
        
        if (automobile == null) {
            throw new ResourceNotFoundException("Automobile not found for id " + maintenance.getAutomobile().getId());
        }

        maintenance.setAutomobile(automobile); 
        
        return maintenance;
    }
}

package com.maintenanceproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maintenanceproject.entity.Maintenance;

@Service
public interface MaintenanceService {

    List<Maintenance> getAllMaintenanceRecords();
    Maintenance getMaintenanceById(Long id);
    List<Maintenance> getMaintenanceByAutomobileId(Long automobileId);
    Maintenance createMaintenance(Maintenance maintenance);
    Maintenance updateMaintenance(Long id, Maintenance maintenance);
    void deleteMaintenance(Long id);
	Maintenance getMaintenanceWithAutomobile(Long id);
    
}

package com.maintenanceproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maintenanceproject.entity.Maintenance;
import com.maintenanceproject.service.MaintenanceService;

@RestController
@RequestMapping("/maintenance")
public class MaintenanceController {

    @Autowired
    private MaintenanceService maintenanceService;

    @GetMapping("/all")
    public List<Maintenance> getAllMaintenanceRecords() {
        return maintenanceService.getAllMaintenanceRecords();
    }

    @GetMapping("/{id}")
    public Maintenance getMaintenanceById(@PathVariable Long id) {
        return maintenanceService.getMaintenanceById(id);
    }

    @PostMapping("/save")
    public Maintenance createMaintenance(@RequestBody Maintenance maintenance) {
        return maintenanceService.createMaintenance(maintenance);
    }

    @PutMapping("/{id}")
    public Maintenance updateMaintenance(@PathVariable Long id, @RequestBody Maintenance maintenance) {
        return maintenanceService.updateMaintenance(id, maintenance);
    }

    @DeleteMapping("/{id}")
    public void deleteMaintenance(@PathVariable Long id) {
        maintenanceService.deleteMaintenance(id);
    }

    @GetMapping("/automobile/{automobileId}")
    public List<Maintenance> getMaintenanceByAutomobileId(@PathVariable Long automobileId) {
        return maintenanceService.getMaintenanceByAutomobileId(automobileId);
    }

    @GetMapping("/{id}/automobile")
    public Maintenance getMaintenanceWithAutomobile(@PathVariable Long id) {
        return maintenanceService.getMaintenanceWithAutomobile(id);
    }
}

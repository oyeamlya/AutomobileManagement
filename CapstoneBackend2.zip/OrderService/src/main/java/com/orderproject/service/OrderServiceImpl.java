package com.orderproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.orderproject.entity.Automobile;
import com.orderproject.entity.Customer;
import com.orderproject.entity.Orders;
import com.orderproject.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private RestTemplate restTemplate; 

	@Override
	public List<Orders> getAllOrders() {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}

	@Override
	public Orders getOrderById(Long id) {
		// TODO Auto-generated method stub
		 return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found with id " + id));
	}

	@Override
	public Orders createOrder(Orders orders) {
		// TODO Auto-generated method stub
		return orderRepository.save(orders);
	}

	@Override
	public Orders updateOrder(Long id, Orders orders) {
		// TODO Auto-generated method stub
		 Orders orderDetails = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found with id " + id));

		 orderDetails.setDate(orders.getDate());
		 orderDetails.setCustomer(orders.getCustomer());
		 orderDetails.setAutomobile(orders.getAutomobile());

	     return orderRepository.save(orderDetails);
	}

	@Override
	public void deleteOrder(Long id) {
		// TODO Auto-generated method stub
		Orders order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found with id " + id));
        orderRepository.delete(order);
		
	}

	@Override
	public List<Orders> getOrdersByCustomerId(Long customerId) {
		// TODO Auto-generated method stub
		return orderRepository.findByCustomerId(customerId);
	}
	
	@Override
	public Orders getOrderDetails(Long id) {
		// TODO Auto-generated method stub
        Orders order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found!"));

        // Fetch Customer details
        Customer customer = restTemplate.getForObject(
            "http://localhost:8083/customers/" + order.getCustomer().getId(),
            Customer.class
        );
        order.setCustomer(customer);

        // Fetch Automobile details
        Automobile automobile = restTemplate.getForObject(
            "http://localhost:8081/automobiles/" + order.getAutomobile().getId(),
            Automobile.class
        );
        order.setAutomobile(automobile);

        return order;
    }

}


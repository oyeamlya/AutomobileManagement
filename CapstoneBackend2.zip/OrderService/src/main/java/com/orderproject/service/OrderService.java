package com.orderproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.orderproject.entity.Orders;

@Service
public interface OrderService {
	List<Orders> getAllOrders();
    Orders getOrderById(Long id);
    Orders createOrder(Orders orders);
    Orders updateOrder(Long id, Orders orders);
    void deleteOrder(Long id);
    List<Orders> getOrdersByCustomerId(Long customerId);
    Orders getOrderDetails(Long id);
}

package com.inventoryproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.inventoryproject.entity.Automobile;
import com.inventoryproject.entity.Inventory;
import com.inventoryproject.entity.Manufacturer;
import com.inventoryproject.exception.ResourceNotFoundException;
import com.inventoryproject.repository.InventoryRepository;

@Service
public class InventoryServiceImpl implements InventoryService{

	@Autowired
    private InventoryRepository inventoryRepository;
	
	@Autowired
    private RestTemplate restTemplate;

	@Override
	public List<Inventory> getAllInventories() {
		// TODO Auto-generated method stub
		return inventoryRepository.findAll();
	}

	@Override
	public Inventory getInventoryById(Long id) {
		// TODO Auto-generated method stub
		return inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found with id " + id));
	}

	@Override
	public Inventory createInventory(Inventory inventory) {
		// TODO Auto-generated method stub
		return inventoryRepository.save(inventory);
	}

	@Override
	public Inventory updateInventory(Long id, Inventory inventory) {
		// TODO Auto-generated method stub
		Inventory existingInventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found with id " + id));

        existingInventory.setQuantity(inventory.getQuantity());
        return inventoryRepository.save(existingInventory);
	}

	@Override
	public void deleteInventory(Long id) {
		// TODO Auto-generated method stub
		Inventory inventory = inventoryRepository.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("Automobile not found with id "+id));
		inventoryRepository.delete(inventory);
	}

	@Override
    public int getQuantityByAutomobileId(Long automobileId) {
		// TODO Auto-generated method stub
        Inventory inventory = getInventoryByAutomobileId(automobileId);
        return inventory.getQuantity();
    }
	
	@Override
	public Inventory getInventoryByAutomobileId(Long automobileId) {
		// TODO Auto-generated method stub
		return inventoryRepository.findByAutomobileId(automobileId)
        .orElseThrow(() -> new ResourceNotFoundException("Inventory not found for automobile with id " + automobileId));
	}
	
	public Inventory getAutomobileWithManufacturer(Long id) {
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found with id " + id));

        Automobile automobile = restTemplate.getForObject(
            "http://localhost:8081/automobile/" + inventory.getAutomobile().getId(), 
            Automobile.class
        );
        
        if (automobile == null) {
            throw new ResourceNotFoundException("Automobile not found for id " + inventory.getAutomobile());
        }

        Manufacturer manufacturer = restTemplate.getForObject(
            "http://localhost:8082/manufacturers/" + automobile.getManufacturer().getId(), 
            Manufacturer.class
        );

        inventory.setAutomobile(automobile);
        return inventory;
    }
	
}

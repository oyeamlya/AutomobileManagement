package com.inventoryproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.inventoryproject.entity.Inventory;

@Service
public interface InventoryService {

	List<Inventory> getAllInventories();
    Inventory getInventoryById(Long id);
    Inventory createInventory(Inventory inventory);
    Inventory updateInventory(Long id, Inventory inventory);
    void deleteInventory(Long id);
    Inventory getInventoryByAutomobileId(Long automobileId);
	int getQuantityByAutomobileId(Long automobileId);
}
